from flask import Flask, redirect, url_for, request
import urllib.request as ur
from bs4 import BeautifulSoup

app = Flask(__name__)


@app.route('/success/<name>')
def success(name):
    print(name)
    s = ur.urlopen(name)
    html = s.read()
    print(html)
    soup = BeautifulSoup(html)

    # kill all script and style elements
    for script in soup(["script", "style"]):
        script.extract()  # rip it out

    # get text
    text = soup.get_text()

    # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())
    # break multi-headlines into a line each
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)

    print(text)
    return 'Following topics found'


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        user = str(request.form['nm'])
        return success(user)
    else:
        user = request.args.get('nm')
        return redirect(url_for('success', name=user))


if __name__ == "__main__":
    app.run(debug=True)

